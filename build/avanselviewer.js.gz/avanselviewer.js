import { PerspectiveCamera, PlaneGeometry, MeshBasicMaterial, TextureLoader, DoubleSide, Mesh, Group, MathUtils, BoxGeometry, BackSide, Vector2, Raycaster, Scene, WebGLRenderer, Clock } from 'three';

function createCamera(container) {

  const fov = 70;
  const aspect = container.clientWidth / container.clientHeight;
  const near = 0.1;
  const far = 200;

  const camera = new PerspectiveCamera(fov, aspect, near, far);

  camera.position.set(0, 0, 0);

  camera.tick = (delta) => { };

  return camera;
}

const tileBase = 100;
const maxLevels = 16;

var ImageType;
(function (ImageType) {
    ImageType[ImageType["Sphere"] = 0] = "Sphere";
    ImageType[ImageType["Cylinder"] = 1] = "Cylinder";
    ImageType[ImageType["Cubestrip"] = 2] = "Cubestrip";
})(ImageType || (ImageType = {}));
var StripType;
(function (StripType) {
    StripType[StripType["Type1x6"] = 0] = "Type1x6";
    StripType[StripType["Type2x3"] = 1] = "Type2x3";
    StripType[StripType["Type3x2"] = 2] = "Type3x2";
    StripType[StripType["Type6x1"] = 3] = "Type6x1";
})(StripType || (StripType = {}));

function createTile(name, side, level, data, source) {
    const url = source()(side, level, data.x, data.y);
    const tileBaseSize = tileBase + maxLevels - level;
    const half = tileBaseSize / 2;
    const offsetX = data.width / 2 - half + data.offsetX;
    const offsetY = half - data.height / 2 - data.offsetY;
    const geometry = new PlaneGeometry(data.width, data.height);
    
    let material;
    
    material = new MeshBasicMaterial({ map: new TextureLoader().load(url), depthWrite: true, transparent: true, opacity: 1});

    material.side = DoubleSide;
    const tile = new Mesh(geometry, material);
    tile.name = name;
    tile.position.set(offsetX, offsetY, 0);
    return tile;
}

const sidePosition = (side, level) => {
    const tileBaseSize = tileBase + maxLevels - level;
    const half = tileBaseSize / 2;
    if(side == 'f') return [ 0, 0, half ]
    if(side == 'b') return [ 0, 0, -half ]
    if(side == 'l') return [ half, 0, 0 ]
    if(side == 'r') return [ -half,  0, 0 ]
    if(side == 'u') return [ 0, half, 0 ]
    if(side == 'd') return [ 0, -half, 0 ]
    return [0, 0, 0]
};

const sideRotation = side => {
    if(side =='f') return [0, MathUtils.degToRad(180), 0]
    if(side =='b') return [0, MathUtils.degToRad(0), 0]
    if(side =='l') return [0, MathUtils.degToRad(-90), 0]
    if(side =='r') return [0, MathUtils.degToRad(90), 0]
    if(side =='d') return [MathUtils.degToRad(90), MathUtils.degToRad(180), 0]
    if(side =='u') return [MathUtils.degToRad(-90), MathUtils.degToRad(180), 0]
    return [0, 0, 0]
};

function createSide(side, level, tiles, source) {
    const group = new Group();
    const position = sidePosition(side, level);
    const rotation = sideRotation(side);
    group.position.set(position[0], position[1], position[2] );
    group.rotation.set(rotation[0], rotation[1], rotation[2] );
    group.renderOrder = level + 1;
    group.name = level + '-' + side;
    for(var i = 0; i < tiles.length; i++){
        const data = tiles[i];
        const name = level + '-' + side + '-' + data.x + '-' + data.y;
        group.add(createTile(name, side, level, data, source));
    }
    return group
}

function updateSide(group, side, level, tiles, source, meshes) {
    for(var i = 0; i < tiles.length; i++){
        const data = tiles[i];
        const name = level + '-' + side + '-' + data.x + '-' + data.y;
        if(!group.getObjectByName(name)){
            group.add(createTile(name, side, level, data, source));
        }
    }
    /*
    for(var i = group.children.length - 1; i >= 0; i--){
        if(!meshes.includes(group.children[i].name)){
            group.remove( group.children[i] );
        }
    }
    */
}

function deleteSide(group) {
    for(var i = group.children.length - 1; i >= 0; i--){
        group.remove( group.children[i] );
    }
}

const minFor = (value, count, extend) => {
    value = Math.round(value * count) - extend;
    if (value < 0)
        value = 0;
    return value;
};
const maxFor = (value, count, extend) => {
    value = Math.round(value * count) + extend;
    if (value > (count - 1))
        value = count - 1;
    return value;
};
const tilesFor = (level, levelData, bounds) => {
    var _a, _b;
    if (!((_a = bounds === null || bounds === void 0 ? void 0 : bounds.x) === null || _a === void 0 ? void 0 : _a.min) && !((_b = bounds === null || bounds === void 0 ? void 0 : bounds.x) === null || _b === void 0 ? void 0 : _b.max))
        return [];
    const { tileSize, size } = levelData;
    const tileBaseSize = tileBase + maxLevels - level;
    const tileSizePart = tileSize / (size / tileBaseSize);
    const tiles = [];
    const max = Math.ceil(tileBaseSize / tileSizePart);
    let xMin = minFor(bounds.x.min, max, 2);
    let xMax = maxFor(bounds.x.max, max, 2);
    let yMin = minFor(bounds.y.min, max, 2);
    let yMax = maxFor(bounds.y.max, max, 2);
    for (var x = xMin; x <= xMax; x++) {
        for (var y = yMin; y <= yMax; y++) {
            if (x >= xMin && x <= xMax && y >= yMin && y <= yMax) {
                const offsetX = x * tileSizePart;
                const offsetY = y * tileSizePart;
                const width = ((x + 1) * tileSizePart) > tileBaseSize ? (tileBaseSize - x * tileSizePart) : tileSizePart;
                const height = ((y + 1) * tileSizePart) > tileBaseSize ? (tileBaseSize - y * tileSizePart) : tileSizePart;
                tiles.push({ x, y, offsetX, offsetY, width, height });
            }
        }
    }
    return tiles;
};
const normLng = (lng) => {
    while (lng > 360)
        lng -= 360;
    while (lng < 0)
        lng += 360;
    return lng;
};

function createCube() {
    const boxSize = tileBase + maxLevels + 2;
    const geometry = new BoxGeometry(boxSize, boxSize, boxSize);
    const material = new MeshBasicMaterial({ color: 0x00ff00 });
    material.side = BackSide;
    material.opacity = 1;
    material.transparent = true;
    return new Mesh(geometry, material);
}

class MultiResPano {
    constructor(levels, source, controls, camera) {
        this.pixelsMin = 0.5;
        this.pixelsMax = 5;
        this.levels = levels;
        this.source = source;
        this.controls = controls;
        this.camera = camera;
        this.visible = {
            pixels: [],
            maxLevel: 0,
            sides: {},
            meshes: []
        };
        this.cube = createCube();
    }
    createPano() {
        this.pano = new Group();
        this.pano.renderOrder = 2;
        this.pano.name = 'multires-pano';
        return this.pano;
    }
    pixelsBySize(size, fov) {
        const height = this.controls.canvas.parentElement.clientHeight;
        const number = height / (0.9 * fov * size / 100);
        return {
            number,
            visible: number >= this.pixelsMin && number <= this.pixelsMax
        };
    }
    minFov(size, max) {
        const height = this.controls.canvas.parentElement.clientHeight;
        return (height * 100) / (size * 0.9 * max);
    }
    pointSideXY(point) {
        const size = (maxLevels + tileBase + 2);
        const mul = 1000000;
        const hs = size / 2;
        const hsMul = (hs * mul);
        const x = Math.round(point.x * mul);
        const y = Math.round(point.y * mul);
        const z = Math.round(point.z * mul);
        if (z === hsMul)
            return { side: 'f', x: 1 - (point.x + hs) / size, y: 1 - (point.y + hs) / size };
        if (z === -hsMul)
            return { side: 'b', x: (point.x + hs) / size, y: 1 - (point.y + hs) / size };
        if (x === hsMul)
            return { side: 'l', x: (point.z + hs) / size, y: 1 - (point.y + hs) / size };
        if (x === -hsMul)
            return { side: 'r', x: (hs - point.z) / size, y: 1 - (point.y + hs) / size };
        if (y === hsMul)
            return { side: 'u', x: 1 - (point.x + hs) / size, y: (point.z + hs) / size };
        if (y === -hsMul)
            return { side: 'd', x: 1 - (point.x + hs) / size, y: 1 - (point.z + hs) / size };
    }
    sidesBounds() {
        const sides = {};
        for (var i = 0; i < this.visible.points.length; i++) {
            let point = this.visible.points[i];
            const sideXY = this.pointSideXY(point);
            if (!sides[sideXY.side])
                sides[sideXY.side] = { points: [], bounds: { x: {}, y: {} } };
            sides[sideXY.side].points.push({ x: sideXY.x, y: sideXY.y });
        }
        for (var side in sides) {
            for (var i = 0; i < sides[side].points.length; i++) {
                let point = sides[side].points[i];
                if (!sides[side].bounds.x.min || sides[side].bounds.x.min > point.x)
                    sides[side].bounds.x.min = point.x;
                if (!sides[side].bounds.x.max || sides[side].bounds.x.max < point.x)
                    sides[side].bounds.x.max = point.x;
                if (!sides[side].bounds.y.min || sides[side].bounds.y.min > point.y)
                    sides[side].bounds.y.min = point.y;
                if (!sides[side].bounds.y.max || sides[side].bounds.y.max < point.y)
                    sides[side].bounds.y.max = point.y;
            }
        }
        return sides;
    }
    screenPoints(max, size) {
        let screenPoints = [];
        let points = [];
        const min = -max;
        const step = (max - min) / (size - 1);
        for (var x = min; x <= max; x += step) {
            for (var y = min; y <= max; y += step) {
                screenPoints.push(new Vector2(x, y));
            }
        }
        const raycaster = new Raycaster();
        for (var i in screenPoints) {
            raycaster.setFromCamera(screenPoints[i], this.camera);
            points.push(raycaster.intersectObject(this.cube)[0].point);
        }
        return points;
    }
    sidesVisibleTiles() {
        this.visible.meshes = [];
        const sides = ['f', 'b', 'u', 'd', 'l', 'r'];
        for (var level in this.visible.pixels) {
            const levelInt = parseInt(level);
            if (this.visible.pixels[level].visible) {
                for (var side in this.visible.sides) {
                    if (!this.visible.sides[side].tiles) {
                        this.visible.sides[side].tiles = {};
                    }
                    this.visible.sides[side].tiles[level] = tilesFor(levelInt, this.levels[level], this.levels[level].fallback ? { x: { min: -1.1, max: 1.1 }, y: { min: -1.1, max: 1.1 } } : this.visible.sides[side].bounds);
                    this.visible.meshes.push(level + '-' + side);
                    this.visible.meshes = [...this.visible.meshes, ...this.visible.sides[side].tiles[level].map(item => level + '-' + side + '-' + item.x + '-' + item.y)];
                }
                if (this.levels[level].fallback) {
                    for (var i in sides) {
                        const side = sides[i];
                        if (!this.visible.sides[side]) {
                            this.visible.sides[side] = { tiles: {} };
                            this.visible.sides[side].tiles[level] = tilesFor(levelInt, this.levels[level], { x: { min: -1.1, max: 1.1 }, y: { min: -1.1, max: 1.1 } });
                            this.visible.meshes.push(level + '-' + side);
                            this.visible.meshes = [...this.visible.meshes, ...this.visible.sides[side].tiles[level].map(item => level + '-' + side + '-' + item.x + '-' + item.y)];
                        }
                    }
                }
            }
        }
    }
    onPosFovChanged(pos) {
        this.calcVisibleData(pos);
    }
    calcVisibleData(pos) {
        const levels = this.levels.length;
        let hasVisible = false;
        let maxLevel = 0;
        for (var i = 0; i < levels; i++) {
            const item = this.pixelsBySize(this.levels[i].size, pos.fov);
            if (this.levels[i].fallback)
                item.visible = true;
            if (item.visible && !hasVisible)
                hasVisible = true;
            if (item.visible && i > maxLevel)
                maxLevel = i;
            this.visible.pixels[i] = item;
        }
        const lastLevel = this.visible.pixels.length - 1;
        if (lastLevel
            && !this.visible.pixels[lastLevel].visible
            && this.visible.pixels[lastLevel].number > this.pixelsMax) {
            this.visible.pixels[lastLevel].visible = true;
        }
        this.visible.maxLevel = maxLevel;
        if (!hasVisible) {
            if (this.visible.pixels[0].number < this.pixelsMin)
                this.visible.pixels[0].visible = true;
            if (this.visible.pixels[levels - 1].number > this.pixelsMax)
                this.visible.pixels[levels - 1].visible = true;
        }
        this.visible.points = this.screenPoints(1.1, 5);
        this.visible.sides = this.sidesBounds();
        this.controls.fovMin = this.minFov(this.levels[lastLevel].size, 1.25);
        this.sidesVisibleTiles();
    }
    addUpdateVisible() {
        for (var side in this.visible.sides) {
            for (var level in this.visible.sides[side].tiles) {
                const tiles = this.visible.sides[side].tiles[level];
                const name = level + '-' + side;
                const group = this.pano.getObjectByName(name);
                if (group) {
                    updateSide(group, side, level, tiles, this.source, this.visible.meshes);
                }
                else {
                    this.pano.add(createSide(side, level, tiles, this.source));
                }
            }
        }
        const groups = this.pano.children.map(item => item.name);
        for (var i = groups.length - 1; i >= 0; i--) {
            const name = groups[i];
            const [level] = name.split('-');
            if (!this.visible.meshes.includes(name)
                && !this.levels[level].fallback) {
                const group = this.pano.getObjectByName(name);
                if (group) {
                    deleteSide(group);
                    this.pano.remove(group);
                }
            }
        }
        return this.pano;
    }
}

function createScene() {
  const scene = new Scene();

  return scene;
}

let onPointerDownMouseX = 0, onPointerDownMouseY = 0,
lng = 90, lngVector = 90, onPointerDownLng = 0,
lat = 0, latVector = 0, onPointerDownLat = 0,
phi = 0, theta = 0,
fov = 70, fovVector = 70;

class PanoControls {

    constructor(camera, canvas, shouldTween) {
        this.camera = camera;
        this.canvas = canvas;
        this.shouldTween = !!shouldTween;
        this.fovMax = 160;
        this.fovMin = 0.0055;
        this.init();
    }

    getPosition(){
        return { lat, lng: normLng(lng), fov }
    }

    lookAt(lat, lng){
        lat = Math.max( - 90, Math.min( 89.9999999999, lat ) );
        phi = MathUtils.degToRad( 90 - lat );
        theta = MathUtils.degToRad( lng );
  
        const x = 500 * Math.sin( phi ) * Math.cos( theta );
        const y = 500 * Math.cos( phi );
        const z = 500 * Math.sin( phi ) * Math.sin( theta );
        this.camera.lookAt(x, y, z);
    }

    tick(delta) {
        lat = Math.max( - 90, Math.min( 89.9999999999, lat ) );
        if(this.shouldTween){
            if(fovVector != fov){
                let diff = (fov - fovVector) / 10;
                if(Math.abs(fovVector / diff) > 500000){
                    fov = fovVector;
                }else {
                    fov = fov - diff;
                }
                this.canvas.dispatchEvent(new CustomEvent('onFovChanged', {detail: { fov }}));
            }
            let posChanged = false;
            if(latVector != lat){
                let diff = (lat - latVector) / 10;
                if(Math.abs(fov / diff) > 100000){
                    lat = latVector;
                }else {
                    lat = lat - diff;
                }
                posChanged = true;
            }
            if(lngVector != lng){
                let diff = (lng - lngVector) / 10;
                if(Math.abs(fov / diff) > 100000){
                    lng = lngVector;
                }else {
                    lng = lng - diff;
                }
                posChanged = true;
            }
            if(posChanged){
                this.lookAt(lat, lng);
                this.canvas.dispatchEvent(new CustomEvent('onCameraMove', {detail: { lat, lng, fov }}));
            }
        }
    }

    init(){

        this.canvas.addEventListener( 'click', e => {
            this.canvas.dispatchEvent(new CustomEvent('onPanoClick', {detail: e}));
        });

        const onPointerDown = e => {
            if ( e.isPrimary === false ) return;    
            onPointerDownMouseX = e.clientX;
            onPointerDownMouseY = e.clientY;
        
            onPointerDownLng = lng;
            onPointerDownLat = lat;
        
            document.addEventListener( 'pointermove', _onPointerMove );
            document.addEventListener( 'pointerup', onPointerUp );
        };
        
        const _onPointerMove = e => ((e, camera, canvas) => {
            if ( e.isPrimary === false ) return;
            if(this.shouldTween){
                lngVector = ( onPointerDownMouseX - e.clientX ) * camera.fov / 650 + onPointerDownLng;
                latVector = ( e.clientY - onPointerDownMouseY ) * camera.fov / 650 + onPointerDownLat;
            }else {
                lng = ( onPointerDownMouseX - e.clientX ) * camera.fov / 650 + onPointerDownLng;
                lat = ( e.clientY - onPointerDownMouseY ) * camera.fov / 650 + onPointerDownLat;
                this.lookAt(lat, lng);
                canvas.dispatchEvent(new CustomEvent('onCameraMove', {detail: { lat, lng }}));
            }
        })(e, this.camera, this.canvas);
        
        const onPointerUp = (e) => {
            if ( e.isPrimary === false ) return;
            document.removeEventListener( 'pointermove', _onPointerMove );
            document.removeEventListener( 'pointerup', onPointerUp );
        };
        
        const onDocumentMouseWheel = (e, camera, canvas) => {
            if(this.shouldTween){
                fovVector = MathUtils.clamp(fovVector + e.deltaY * fovVector / 1000, this.fovMin, this.fovMax );
            }else {
                fov = MathUtils.clamp(fov + e.deltaY * fov / 1000, this.fovMin, this.fovMax );
                canvas.dispatchEvent(new CustomEvent('onFovChanged', {detail: { fov }}));
            }
        };

        this.canvas.addEventListener( 'pointerdown', onPointerDown );
        document.addEventListener( 'wheel', e => onDocumentMouseWheel(e, this.camera, this.canvas) );

        this.lookAt(lat, lng);
    }

}

function createControls(camera, canvas, shouldTween) {
    const controls = new PanoControls(camera, canvas, shouldTween);
    return controls;
}

function createRenderer() {
  const renderer = new WebGLRenderer({ antialias: true });

  return renderer
}

const setSize = (container, camera, renderer) => {
  camera.aspect = container.clientWidth / container.clientHeight;
  camera.updateProjectionMatrix();

  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setPixelRatio(window.devicePixelRatio);
};

let customOnResize;

class Resizer {
  constructor(container, camera, renderer) {
    setSize(container, camera, renderer);

    window.addEventListener('resize', () => {
      setSize(container, camera, renderer);
      this.onResize();
    });
  }

  onResize(){
    if(typeof customOnResize == 'function') customOnResize();
  }

  setOnResize(fnc){
    customOnResize = fnc;
  }
}

const clock = new Clock();


class Loop {

    constructor(camera, scene, renderer) {
        this.camera = camera;
        this.scene = scene;
        this.renderer = renderer;
        this.updatable = [];
    }

    start() {
        this.renderer.setAnimationLoop((t) => {
            this.tick();
            this.renderer.render(this.scene, this.camera);
        });
    }

    stop() {
        this.renderer.setAnimationLoop(null);
    }

    tick() {
        const delta = clock.getDelta();
        for (const object of this.updatable) {
            object.tick(delta);
        }
    }

}

class AvanselViewer {
    constructor(container, levels, source) {
        this.camera = createCamera(container);
        this.scene = createScene();
        this.renderer = createRenderer();
        this.loop = new Loop(this.camera, this.scene, this.renderer);
        container.append(this.renderer.domElement);
        this.controls = createControls(this.camera, this.renderer.domElement, true);
        {
            this.pano = new MultiResPano(levels, source, this.controls, this.camera);
            this.scene.add(this.pano.createPano());
            const pos = this.controls.getPosition();
            this.controls.lookAt(pos.lat, pos.lng);
            this.updatePosition();
        }
        this.resizer = new Resizer(container, this.camera, this.renderer);
        this.loop.updatable.push(this.controls);
        this.renderer.domElement.addEventListener('onPanoClick', (e) => this.onPanoClick(e));
        this.renderer.domElement.addEventListener('onCameraMove', (e) => this.onCameraMove(e));
        this.renderer.domElement.addEventListener('onFovChanged', (e) => this.onFovChanged(e));
        // TODO: udpate this
        this.resizer.setOnResize(() => {
            //
        });
        this.render();
    }
    render() {
        this.renderer.render(this.scene, this.camera);
    }
    start() {
        this.loop.start();
    }
    stop() {
        this.loop.stop();
    }
    onPanoClick(e) {
        //console.log('click', e.detail);
    }
    onCameraMove(e) {
        this.updatePosition();
    }
    onFovChanged(e) {
        this.updatePosition();
    }
    updatePosition() {
        const pos = this.controls.getPosition();
        this.pano.onPosFovChanged(pos);
        this.pano.addUpdateVisible();
        if (this.camera.fov != pos.fov) {
            this.camera.fov = pos.fov;
            this.camera.updateProjectionMatrix();
        }
    }
}
exports.AvanselViewer = AvanselViewer;
exports.Viewer = () => AvanselViewer;
//# sourceMappingURL=avanselviewer.js.map
